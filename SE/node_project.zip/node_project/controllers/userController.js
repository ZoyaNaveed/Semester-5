const UserServices = require('../services/userServices');
const Course = require('../models/coursemodel');
const Notification = require('../models/notificationmodel');
const Assignment = require('../models/assignmentmodel');
const Result = require('../models/resultsmodel');

exports.createResult = async (req, res) => {
  try {
    const { courseName, courseCode, student, teacher, grade, remarks } = req.body;
    const result = new Result({
      courseName,
      courseCode,
      student,
      teacher,
      grade,
      remarks,
    });

    const savedResult = await result.save();
    res.status(201).json(savedResult);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getResults = async (req, res) => {
  try {
    const results = await Result.find();
    res.status(200).json(results);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};


exports.createAssignment = async (req, res) => {
  try {
    const { title, description, courseCode, deadline } = req.body;
    const assignment = new Assignment({
      title,
      description,
      courseCode,
      deadline,
    });

    if (req.file) {
      // Assuming you are using a middleware like multer for file uploads
      assignment.content = req.file.path;
    }

    const savedAssignment = await assignment.save();
    res.status(201).json(savedAssignment);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getAssignments = async (req, res) => {
  try {
    const assignments = await Assignment.find();
    res.status(200).json(assignments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.removeNotification = async (req, res) => {
    try {
      const notificationId = req.params.id;
  
      // Check if the notification exists
      const existingNotification = await Notification.findById(notificationId);
      if (!existingNotification) {
        return res.status(404).json({ error: 'Notification not found' });
      }
  else{
      // Remove the notification
      await existingNotification.deleteOne();
      res.status(200).json({ message: 'Notification removed successfully' });
  }

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  exports.removeAssignments = async (req, res) => {
    try {
      const assignmentId = req.params.id;
  
      // Check if the notification exists
      const existingassignment = await Assignment.findById(assignmentId);
      if (!existingassignment) {
        return res.status(404).json({ error: 'Assignment not found' });
      }
  else{
      // Remove the notification
      await existingassignment.deleteOne();
      res.status(200).json({ message: 'Assignment removed successfully' });
  }

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };



exports.createNotification = async (req, res) => {
    try {
      const { header, body, courseCode } = req.body;
      const newNotification = new Notification({ header, body, courseCode });
      const savedNotification = await newNotification.save();
      res.status(201).json(savedNotification);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  exports.getNotifications = async (req, res) => {
    try {
      const notifications = await Notification.find();
      res.status(200).json(notifications);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

exports.createCourse = async (req, res) => {
    const { name, code, teacher } = req.body;
  
    try {
      const newCourse = new Course({ name, code, teacher });
      const savedCourse = await newCourse.save();
      res.status(201).json(savedCourse);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  };

  exports.getAllCourses = async (req, res) => {
    try {
      const courses = await Course.find();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };

  exports.deleteCourse = async (req, res) => {
    try {
      const courseId = req.params.id;
  
      // Use Mongoose to find and remove the course by its ID
      const deletedCourse = await Course.findByIdAndDelete(courseId);
  
      if (!deletedCourse) {
        return res.status(404).json({ message: 'Course not found' });
      }
  
      res.status(200).json({ message: 'Course deleted successfully', deletedCourse });
    } catch (error) {
      console.error('Error deleting course:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  };

exports.register = async (req, res, next) => {
    try {
        console.log("---req body---", req.body);
        const { username, email, password } = req.body;
        const duplicate = await UserServices.getUserByEmail(email);
        if (duplicate) {
            throw new Error(`UserName ${email}, Already Registered`)
        }
        const response = await UserServices.registerUser(username, email, password);

        res.json({ status: true, success: 'User registered successfully' });


    } catch (err) {
        console.log("---> err -->", err);
        next(err);
    }
}

exports.login = async (req, res, next) => {
    try {

        const { email, password } = req.body;

        if (!email || !password) {
            throw new Error('Parameter are not correct');
        }
        let user = await UserServices.checkUser(email);
        if (!user) {
            throw new Error('User does not exist');
        }

        const isPasswordCorrect = await user.comparePassword(password);

        if (isPasswordCorrect === false) {
            throw new Error(`Username or Password does not match`);
        }

        // Creating Token

        let tokenData;
        tokenData = { _id: user._id, username: user.username, email: user.email };
    

        const token = await UserServices.generateAccessToken(tokenData,"secret","1h")

        res.status(200).json({ status: true, success: "sendData", token: token });
    } catch (error) {
        console.log(error, 'err---->');
        next(error);
    }
}