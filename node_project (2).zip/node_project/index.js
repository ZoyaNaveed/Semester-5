const app = require("./app");
const db = require('./configuration/db')
const UserModel = require('./models/usermodel')

const port = 3010;

app.listen(port,()=>{
    console.log(`Server Listening on Port http://localhost:${port}`);
})