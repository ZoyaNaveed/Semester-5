const db = require('../configuration/db');
const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const { Schema } = mongoose;


const notificationSchema = new Schema({
    header: {
      type: String,
      required: true,
    },
    body: {
      type: String,
      required: true,
    },
    courseCode: {
      type: String,
      required: true,
    },
  });
  
  const Notification = db.model('Notifications', notificationSchema);
  
  module.exports = Notification;