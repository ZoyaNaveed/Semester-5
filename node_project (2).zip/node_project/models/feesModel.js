const db = require('../configuration/db');
const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const { Schema } = mongoose;


const FeesSchema = new Schema({
    session: {
      type: String,
      required: true,
    },
    deadline: {
      type: Date,
      required: true,
    },
    content: {
      type: String, // Assuming the content is stored as a file path or a reference
    },
  });
  
  const Fees = db.model('Fees', FeesSchema);
  
  module.exports = Fees;