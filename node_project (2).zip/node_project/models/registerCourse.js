const db = require('../configuration/db');
const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const { Schema } = mongoose;


const studentCourseSchema = new mongoose.Schema({
    studentName: {
      type: String,
      required: true,
    },
    courses: [
      {
        courseName: {
          type: String,
          required: true,
        },

        semester: {
          type: String,
          required: true,
        },
      },
    ],
  });
  
  const StudentCourse = db.model('StudentCourses', studentCourseSchema);
  
  module.exports = StudentCourse;