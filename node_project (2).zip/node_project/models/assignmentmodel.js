const db = require('../configuration/db');
const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const { Schema } = mongoose;


const assignmentSchema = new Schema({
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    courseCode: {
      type: String,
      required: true,
    },
    deadline: {
      type: Date,
      required: true,
    },
    content: {
      type: String, // Assuming the content is stored as a file path or a reference
    },
  });
  
  const Assignment = db.model('Assignments', assignmentSchema);
  
  module.exports = Assignment;