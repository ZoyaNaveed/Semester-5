const db = require('../configuration/db');
const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const { Schema } = mongoose;

const courseSchema = new Schema({
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    teacher: { type: String, required: true},
  });
  
  const Course = db.model('Course', courseSchema);
  module.exports = Course;