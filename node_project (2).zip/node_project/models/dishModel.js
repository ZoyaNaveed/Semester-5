const db = require('../configuration/db');
const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const { Schema } = mongoose;


const DishSchema = new Schema({
    ID: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    price: {
      type: String, 
      required: true,
    },
    category: {
        type: String, 
        required: true,
      },
    resturantId: {
        type: String, 
        required: true,
      },
  });
  
  const Dish = db.model('Dish', DishSchema);
  
  module.exports = Dish;