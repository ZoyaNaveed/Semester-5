const db = require('../configuration/db');
const bcrypt = require("bcrypt");
const mongoose = require('mongoose');
const { Schema } = mongoose;

const resultSchema = new Schema({
    courseName: {
      type: String,
      required: true,
    },
    courseCode: {
      type: String,
      required: true,
    },
    student: {
      type: String,
      required: true,
    },
    teacher: {
      type: String,
      required: true,
    },
    grade: {
      type: String,
      required: true,
    },
    remarks: {
      type: String,
    },
  });
  
  const Result = db.model('Results', resultSchema);
  module.exports = Result;