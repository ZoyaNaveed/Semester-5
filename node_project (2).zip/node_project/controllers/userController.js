const UserServices = require('../services/userServices');
const Course = require('../models/coursemodel');
const Notification = require('../models/notificationmodel');
const Assignment = require('../models/assignmentmodel');
const Result = require('../models/resultsmodel');
const Fees = require('../models/feesModel');
const studentCourse = require('../models/registerCourse');
const Dish = require('../models/dishModel');

exports.addDish = async (req, res) => {
  try {
    const { ID, name, price, category, resturantId} = req.body;
    const dish = new Dish({
      ID, name, price, category, resturantId
    });

    const savedDish = await dish.save();
    res.status(201).json(savedDish);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
exports.getDishes = async (req, res) => {
  const { dish } = req.params;

  try {
    // Find the user by studentName
    const user = await Dish.findOne({ dish });

    if (!user) {
      return res.status(404).json({ message: 'Dish not found' });
    }

    res.status(200).json({ message: 'Dish information retrieved successfully', user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};





exports.removeCourse = async (req, res) => {
  const { studentName, courseId } = req.params;

  try {
    // Find the user by studentName
    const user = await studentCourse.findOne({ studentName });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Find the index of the course to remove
    const courseIndex = user.courses.findIndex(course => course._id == courseId);

    if (courseIndex === -1) {
      return res.status(404).json({ message: 'Course not found for the user' });
    }

    // Remove the course from the user's courses array
    user.courses.splice(courseIndex, 1);

    // Save the updated user to the database
    await user.save();

    res.status(200).json({ message: 'Course removed successfully', user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};



exports.registerCourse = async (req, res) => {
  const { studentName, courseName, courseCode, semester } = req.body;

  try {
    // Check if the user exists
    let user = await studentCourse.findOne({ studentName });

    if (!user) {
      // Create a new user if not exists
      user = new studentCourse({
        studentName,
        courses: [{ courseName, semester }],
      });
    } else {
      // Add the course to the existing user
      user.courses.push({ courseName, semester });
    }

    // Save the user to the database
    await user.save();

    res.status(201).json({ message: 'Course registered successfully', user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

exports.getRegisteredCourses = async (req, res) => {
  const { studentName } = req.params;

  try {
    // Find the user by studentName
    const user = await studentCourse.findOne({ studentName });

    if (!user) {
      return res.status(404).json({ message: 'Student not found' });
    }

    res.status(200).json({ message: 'Student information retrieved successfully', user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

exports.downloadFile = async (req, res) => {
  try {
    const userId = req.params.id; // Assuming you have userId in your route params
    const user = await Assignment.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Implement logic to read the file and send it for download
    // In this example, assuming the file is in the 'uploads' directory
    const filePath = user.content;
    res.download(filePath);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.downloadChallan = async (req, res) => {
  try {
    const userId = req.params.id; // Assuming you have userId in your route params
    const user = await Fees.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Implement logic to read the file and send it for download
    // In this example, assuming the file is in the 'uploads' directory
    const filePath = user.content;
    res.download(filePath);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.UploadFees = async (req, res) => {
  try {
    const { session, deadline } = req.body;
    const fees = new Fees({
      session,
      deadline,
    });

    if (req.file) {
      // Assuming you are using a middleware like multer for file uploads
      fees.content = req.file.path;
    }

    const savedFees = await fees.save();
    res.status(201).json(savedFees);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.deleteFee = async (req, res) => {
  try {
    const feeId = req.params.id; // Assuming you pass the fee ID as a route parameter

    // Check if the fee exists
    const fee = await Fees.findById(feeId);
    if (!fee) {
      return res.status(404).json({ error: 'Fee not found' });
    }

    // Perform the deletion
    await Fees.findByIdAndDelete(feeId);

    res.status(200).json({ message: 'Fee deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getFees = async (req, res) => {
  try {
    const fee = await Fees.find();
    res.status(200).json(fee);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.createResult = async (req, res) => {
  try {
    const { courseName, courseCode, student, teacher, grade, remarks } = req.body;
    const result = new Result({
      courseName,
      courseCode,
      student,
      teacher,
      grade,
      remarks,
    });

    const savedResult = await result.save();
    res.status(201).json(savedResult);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getResults = async (req, res) => {
  try {
    const results = await Result.find();
    res.status(200).json(results);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.deleteResult = async (req, res) => {
  try {
    const resultId = req.params.id; // Assuming you pass the result ID as a route parameter

    // Check if the result exists
    const result = await Result.findById(resultId);
    if (!result) {
      return res.status(404).json({ error: 'Result not found' });
    }

    // Perform the deletion
    await Result.findByIdAndDelete(resultId);

    res.status(200).json({ message: 'Result deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.createAssignment = async (req, res) => {
  try {
    const { title, description, courseCode, deadline } = req.body;
    const assignment = new Assignment({
      title,
      description,
      courseCode,
      deadline,
    });

    if (req.file) {
      // Assuming you are using a middleware like multer for file uploads
      assignment.content = req.file.path;
    }

    const savedAssignment = await assignment.save();
    res.status(201).json(savedAssignment);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getAssignments = async (req, res) => {
  try {
    const assignments = await Assignment.find();
    res.status(200).json(assignments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.deleteAssignment = async (req, res) => {
  try {
    const assignmentId = req.params.id; // Assuming you pass the assignment ID as a route parameter

    // Check if the assignment exists
    const assignment = await Assignment.findById(assignmentId);
    if (!assignment) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    // Perform the deletion
    await Assignment.findByIdAndDelete(assignmentId);

    res.status(200).json({ message: 'Assignment deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.removeNotification = async (req, res) => {
    try {
      const notificationId = req.params.id;
  
      // Check if the notification exists
      const existingNotification = await Notification.findById(notificationId);
      if (!existingNotification) {
        return res.status(404).json({ error: 'Notification not found' });
      }
  else{
      // Remove the notification
      await existingNotification.deleteOne();
      res.status(200).json({ message: 'Notification removed successfully' });
  }

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

exports.createNotification = async (req, res) => {
    try {
      const { header, body, courseCode } = req.body;
      const newNotification = new Notification({ header, body, courseCode });
      const savedNotification = await newNotification.save();
      res.status(201).json(savedNotification);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  exports.getNotifications = async (req, res) => {
    try {
      const notifications = await Notification.find();
      res.status(200).json(notifications);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

exports.createCourse = async (req, res) => {
    const { name, code, teacher } = req.body;
  
    try {
      const newCourse = new Course({ name, code, teacher });
      const savedCourse = await newCourse.save();
      res.status(201).json(savedCourse);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  };

  exports.getAllCourses = async (req, res) => {
    try {
      const courses = await Course.find();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };

  exports.deleteCourse = async (req, res) => {
    try {
      const courseId = req.params.id;
  
      // Use Mongoose to find and remove the course by its ID
      const deletedCourse = await Course.findByIdAndDelete(courseId);
  
      if (!deletedCourse) {
        return res.status(404).json({ message: 'Course not found' });
      }
  
      res.status(200).json({ message: 'Course deleted successfully', deletedCourse });
    } catch (error) {
      console.error('Error deleting course:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  };

exports.register = async (req, res, next) => {
    try {
        console.log("---req body---", req.body);
        const { username, email, password } = req.body;
        const duplicate = await UserServices.getUserByEmail(email);
        if (duplicate) {
            throw new Error(`UserName ${email}, Already Registered`)
        }
        const response = await UserServices.registerUser(username, email, password);

        res.json({ status: true, success: 'User registered successfully' });


    } catch (err) {
        console.log("---> err -->", err);
        next(err);
    }
}

exports.login = async (req, res, next) => {
    try {

        const { email, password } = req.body;

        if (!email || !password) {
            throw new Error('Parameter are not correct');
        }
        let user = await UserServices.checkUser(email);
        if (!user) {
            throw new Error('User does not exist');
        }

        const isPasswordCorrect = await user.comparePassword(password);

        if (isPasswordCorrect === false) {
            throw new Error(`Username or Password does not match`);
        }

        // Creating Token

        let tokenData;
        tokenData = { _id: user._id, username: user.username, email: user.email };
    

        const token = await UserServices.generateAccessToken(tokenData,"secret","1h")

        res.status(200).json({ status: true, success: "sendData", token: token });
    } catch (error) {
        console.log(error, 'err---->');
        next(error);
    }
}