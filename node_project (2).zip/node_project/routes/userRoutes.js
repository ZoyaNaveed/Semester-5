const router = require("express").Router();
const UserController = require('../controllers/userController');
const multer = require('multer');


router.post("/register",UserController.register);

router.post("/login", UserController.login);

router.post('/courses', UserController.createCourse);

router.get('/courses', UserController.getAllCourses);

router.delete('/courses/:id', UserController.deleteCourse);

router.post('/notifications', UserController.createNotification);

router.get('/notifications', UserController.getNotifications);

router.delete('/notifications/:id', UserController.removeNotification);

router.post('/results', UserController.createResult);

router.get('/results', UserController.getResults);

router.delete('/results/:id', UserController.deleteResult);

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './uploads'); // Specify the upload directory
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + '-' + file.originalname);
    },
  });
  
  const upload = multer({ storage: storage });
  
  // Define the assignment routes
  
router.post('/assignments', upload.single('content'), UserController.createAssignment);

router.get('/assignments', UserController.getAssignments);

router.delete('/assignments/:id', UserController.deleteAssignment);

router.post('/fees', upload.single('content'), UserController.UploadFees);

router.delete('/fees/:id', UserController.deleteFee);

router.get('/fees', UserController.getFees);

router.get('/assignments/:id/download', UserController.downloadFile);

router.get('/fees/:id/download', UserController.downloadChallan);

router.post('/registercourse', UserController.registerCourse);

router.get('/registercourse/:studentName', UserController.getRegisteredCourses);

router.delete('/registercourse/:studentName/:courseId', UserController.removeCourse);

router.post('/dishes', UserController.addDish);

router.get('/dishes', UserController.getDishes);


//define results routes

module.exports = router;